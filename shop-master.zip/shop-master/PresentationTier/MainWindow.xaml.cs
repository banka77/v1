﻿using System.Collections.Generic;
using System.Windows;
using DataTier;
using LogicTier;

namespace PresentationTier
{
    public partial class MainWindow : Window
    {
        private Автосалон автосалон; // поле для хранения текущего автосалона

        public MainWindow()
        {
            InitializeComponent(); // всегда вызывается первым
            автосалон = new Автосалон(); // пока пустой
            this.DataContext = автосалон;
        }

        private void btn_open_file_Click(object sender, RoutedEventArgs e)
        {
            // Чтение автомобилей из файла
            List<Автомобиль> автомобили = Автомобили.ПолучитьВсеАвтомобилиИзФайла();

            if (автомобили == null || автомобили.Count == 0)
            {
                MessageBox.Show("В файле нет данных об автомобилях!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Создание списка позиций автомобилей
            List<АвтомобильнаяПозиция> позиции = new List<АвтомобильнаяПозиция>();
            foreach (var авто in автомобили)
            {
                позиции.Add(new АвтомобильнаяПозиция(авто));
            }

            // Обновление автосалона и установка DataContext
            автосалон = new Автосалон(позиции);
            this.DataContext = автосалон;
        }
    }
}
