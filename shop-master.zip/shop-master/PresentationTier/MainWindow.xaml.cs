﻿using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Windows;
using DataTier;
using LogicTier;
using Microsoft.Win32;

namespace PresentationTier
{
    public partial class MainWindow : Window
    {
        private Автосалон автосалон; // поле для хранения текущего автосалона

        public MainWindow()
        {
            InitializeComponent(); // всегда вызывается первым
            автосалон = new Автосалон(); // пока пустой
            this.DataContext = автосалон;
        }

        private void btn_open_file_Click(object sender, RoutedEventArgs e)
        {
            // Чтение автомобилей из файла
            List<Автомобиль> автомобили = Автомобили.ПолучитьВсеАвтомобилиИзФайла();

            if (автомобили == null || автомобили.Count == 0)
            {
                MessageBox.Show("В файле нет данных об автомобилях!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Создание списка позиций автомобилей
            List<АвтомобильнаяПозиция> позиции = new List<АвтомобильнаяПозиция>();
            foreach (var авто in автомобили)
            {
                позиции.Add(new АвтомобильнаяПозиция(авто));
            }

            // Обновление автосалона и установка DataContext
            автосалон = new Автосалон(позиции);
            this.DataContext = автосалон;
        }

        private void write_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Текстовые файлы(*.txt)|*.txt|Скрипты(*.sql)|*.sql|Документы(*.docx)|*.docx";
            if (sfd.ShowDialog() == true)
            {
                string FilePath = sfd.FileName;
                StreamWriter swriter = new StreamWriter(FilePath);

                var магазин = (LogicTier.Автосалон)DataContext;

                //проходим по всем товарам магазина и сохраняем их 
                foreach (var товарнаяПозиация in магазин.СписокАвтомобилей)
                {
                    //записываем представление товара в файлик наш (перезаписываем или создаём новый)
                    swriter.WriteLine(товарнаяПозиация.Представление);
                }
                //если подтвердил сохранение - сообщение об выполнении 
                swriter.Close();
                MessageBox.Show($"Данные сохранены в файл {FilePath}");
            }
            else
            { //если отменил - сообщение об отказе
                MessageBox.Show("Пользователь отказался от окна сохранения");
            }
        }

        private void add_Click(object sender, RoutedEventArgs e)
        {
            string line = t1.Text;


            var parts = line.Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries)
                             .Select(p => p.Trim())
                             .ToArray();
            if (parts.Length != 4)
            {
                MessageBox.Show("Ошибка: неверный формат данных.");
                return;
            }

            //создание нового товара 
            var автомобиль = new DataTier.Автомобиль()
            {
                Модель = parts[0].Trim(),
                Производитель = parts[1].Trim(),
                Стоимость = float.Parse(parts[2].Trim(), CultureInfo.InvariantCulture),
                Пробег = int.Parse(parts[3].Trim())
            };

            //добавляем товар в магазин
            var автосалон = (LogicTier.Автосалон)DataContext; //тут мы получаем ссылку на Магазин.cs - он источник данных,

            автосалон.СписокАвтомобилей.Add(new LogicTier.АвтомобильнаяПозиция(автомобиль));//затем добавляет новый товар в коллекцию товаорв магащина

            //Ооищение поля
            t1.Clear();
        }
    }
}
