﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataTier;

namespace LogicTier
{
    public class Автосалон
    {
        private List<АвтомобильнаяПозиция> _автомобили;

        public Автосалон()
        {
            _автомобили = new List<АвтомобильнаяПозиция>();
        }

        public Автосалон(List<АвтомобильнаяПозиция> позиции)
        {
            _автомобили = позиции;
        }

        public List<АвтомобильнаяПозиция> СписокАвтомобилей => _автомобили;

        public string НаименованиеАвтосалона => "Наш автосалон";

        public float СуммарнаяСтоимость => _автомобили.Sum(p => p.Стоимость);

        public АвтомобильнаяПозиция АвтоСМинПробегом =>
            _автомобили.OrderBy(p => p.Пробег).FirstOrDefault();

    public АвтомобильнаяПозиция АвтоСНаименьшимПробегом
        {
            get
            {
                return _автомобили.OrderBy(a => a.Пробег).FirstOrDefault();
            }
        }

    }
}
