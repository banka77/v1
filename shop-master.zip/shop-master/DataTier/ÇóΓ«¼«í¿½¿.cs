﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTier
{
    public class Автомобили
    {
        public static List<Автомобиль> ПолучитьВсеАвтомобилиИзФайла()
        {
            List<Автомобиль> list = new List<Автомобиль>();

            OpenFileDialog openFileDialog = new OpenFileDialog();

            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;

                using (StreamReader reader = new StreamReader(filePath, Encoding.UTF8))
                {
                    while (!reader.EndOfStream)
                    {
                        string line = reader.ReadLine();

                        if (string.IsNullOrWhiteSpace(line)) // Пропустить пустые строки
                            continue;

                        string[] data = line.Split(";");
                        if (data.Length == 4) // Проверка, что строка содержит все необходимые данные
                        {
                            Автомобиль авто = new Автомобиль()
                            {
                                Модель = data[0].Trim(),
                                Производитель = data[1].Trim(),
                                Стоимость = float.Parse(data[2].Trim(), CultureInfo.InvariantCulture),
                                Пробег = int.Parse(data[3].Trim())
                            };

                            list.Add(авто);
                        }
                    }
                }
            }

            return list;
        }

    }
}

